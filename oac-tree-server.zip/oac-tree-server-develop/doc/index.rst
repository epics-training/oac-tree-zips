.. oac-tree-server documentation master file, created by
   sphinx-quickstart on Thu Jan 20 15:49:09 2022.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to oac-tree-server's documentation!
===========================================

**oac-tree-server** is a C++ library for oac-tree servers.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
