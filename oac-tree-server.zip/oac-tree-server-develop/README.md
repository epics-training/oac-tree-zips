# Test automation server application

To test the current automation server application, run the executable:

```bash
oac-tree-server -s test-auto [PROCEDURE_XML_FILE]...
```

This will run an automation server with a list of procedures parsed from the given files.
