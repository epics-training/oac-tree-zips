Welcome to oac-tree-plugin-epics's documentation!
==================================================

``oac-tree-plugin-epics`` is a oac-tree plugin that provides instructions and variables to interface with EPICSv7 process variables. It supports both ChannelAccess and PvAccess.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   overview
   usage
   instructions
   variables
