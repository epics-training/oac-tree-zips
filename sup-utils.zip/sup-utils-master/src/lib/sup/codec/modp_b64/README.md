# Inclusion of ModpB64Chromium

This base64 encoding/decoding implementation was adapted from [Chromium](https://github.com/adobe/chromium.git), with commit ID:

```txt
cfe5bf0b51b1f6b9fe239c2a3c2f2364da9967d7
```

All changes (except adding of this README file and the CMakeLists.txt file) can be seen in the git history, as the first commit adding these files contains no changes with respect to the chromium repository.
