Welcome to oac-tree-plugin-control's documentation!
====================================================

``oac-tree-plugin-control`` is a oac-tree plugin that provides common compound instructions in control system logic.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   overview
   usage
   instructions
