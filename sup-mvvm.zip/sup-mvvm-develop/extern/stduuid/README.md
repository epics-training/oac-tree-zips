# stduuid library for standard identifiers generation

- Source https://github.com/mariusbancila/stduuid
