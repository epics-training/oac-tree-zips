Standard items
==============

.. doxygenclass:: mvvm::PropertyItem
  :members:

.. doxygenclass:: mvvm::VectorItem
  :members:

.. doxygenclass:: mvvm::BasicAxisItem
  :members:

.. doxygenclass:: mvvm::ViewportAxisItem
  :members:

.. doxygenclass:: mvvm::BinnedAxisItem
  :members:

.. doxygenclass:: mvvm::FixedBinAxisItem
  :members:

.. doxygenclass:: mvvm::PointwiseAxisItem
  :members:

.. doxygenclass:: mvvm::ContainerItem
  :members:

.. doxygenclass:: mvvm::Data1DItem
  :members:

.. doxygenclass:: mvvm::GraphItem
  :members:

.. doxygenclass:: mvvm::ViewportItem
  :members:

.. doxygenclass:: mvvm::GraphViewportItem
  :members:

.. doxygenclass:: mvvm::LinkedItem
  :members:

.. doxygenclass:: mvvm::TextItem
  :members:

.. doxygenclass:: mvvm::PenItem
  :members:
