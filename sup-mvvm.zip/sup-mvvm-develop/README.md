# Operational Applications UI foundation

Collection of C++/Qt common components for Operational Application User
Interfaces.

## Requirements

- C++17
- CMake 3.14
- Qt6
- libxml2

