# Example "collidingmice".

The example shows how to modify the third-party application to provide serialization, undo-redo, 
and proper model-view relations. We have modified Qt's example "colliding mice".
