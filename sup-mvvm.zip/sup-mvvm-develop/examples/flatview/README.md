# Example "flatview"

Demonstrates special type of a view where model is presented with standard widgets in a grid layout.

![flatview](flatview.png)
