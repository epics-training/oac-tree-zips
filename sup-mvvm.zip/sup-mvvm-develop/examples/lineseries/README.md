# Example "lineseries".

The example shows how to plot one-dimensional line series using wrappers around QtCharts library. 

![plotgraphs](lineseries.png)

