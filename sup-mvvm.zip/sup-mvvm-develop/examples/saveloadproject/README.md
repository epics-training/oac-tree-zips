#Example "Save and load project"

This example explains how to organize actions related to project save and load,
including access to information about recent saves.

![saveloadproject](saveloadproject.png)
