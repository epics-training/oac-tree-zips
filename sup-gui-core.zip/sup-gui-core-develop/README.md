# Common GUI core libraries for Operation Application user interfaces

Contains SUP and EPICS related models and viewmodels, fancy widgets, AnyValueEditor.

- C++/Qt
- Intended for sequencer-gui and psps-editor
- Depend on sup-mvvm library

