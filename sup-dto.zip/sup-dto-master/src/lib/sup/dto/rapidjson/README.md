This include folder was checked out from tag v1.1.0 of
[RapidJSON](https://github.com/Tencent/rapidjson/)

See `license.txt` for a summary of the applicable license.