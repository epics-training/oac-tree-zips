Welcome to sup-mathexpr's documentation!
==================================================

This is a work in progress.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
