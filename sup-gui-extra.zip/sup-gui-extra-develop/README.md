# Collection of convenience Qt widgets for Operation Application user interfaces.

- No other dependencies than Qt.
