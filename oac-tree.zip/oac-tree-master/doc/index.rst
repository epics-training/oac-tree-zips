Welcome to oac-tree's documentation!
=====================================

**oac-tree** is a C++ framework for creating and executing automation procedures. It is developed
in the context of the ITER Supervision and Automation System (SUP).


.. toctree::
   :maxdepth: 2
   :caption: Contents:

   introduction
   coreinstructionsvariables
   plugincreation
   API

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
