============================
 Core Instructions/Variables
============================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   coreinstructions
   corevariables
